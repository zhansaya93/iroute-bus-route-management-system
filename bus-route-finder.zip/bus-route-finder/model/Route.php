<?php
Class Route{
	private $routeNo;
	private $start;
	private $end;
	private $halts;
	
	function __construct($routeNo, $start, $end, $halts = array()){
		$this->routeNo = $routeNo;
		$this->start = $start;
		$this->end = $end;
		$this->halts = $halts;
	}
	
	public function getRouteNo() {
		return $this->routeNo;
	}
	
	public function getStart() {
		return $this->start;
	}
	
	public function getEnd() {
		return $this->end;
	}
	
	public function getHalts() {
		return $this->halts;
	}
}
?>