<?php

class Halt{
	private $id;
	private $name;
	private $otherNames;
	private $latitude;
	private $longitude;
	
	public function __construct($id=NULL, $name, $otherNames = '', $latitude, $longitude){
		$this->id = $id;
		$this->name = $name;
		$this->otherNames = $otherNames;
		$this->latitude = $latitude;
		$this->longitude = $longitude;
		$this->routesThrough = $routesThrough;
	}
	
	public function getName() {
		return $this->name;
	}
	
	public function getLatitude() {
		return $this->latitude;
	}
	
	public function getLongitude() {
		return $this->longitude;
	}
	
	public function getId() {
		return $this->id;
	}
	
	public function getOtherNames() {
		return $this->otherNames;
	}	
	
}

?>