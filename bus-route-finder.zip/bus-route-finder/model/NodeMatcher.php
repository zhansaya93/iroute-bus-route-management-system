<?php
class NodeMatcher {
	private $db;
	
	public function __construct(){
		$this->db = new DBAccess();
	}
	
	public function getNodesContaining($key) {
		$query = "SELECT id, name FROM halt WHERE name LIKE '%$key%' OR alias LIKE '%$key%' LIMIT 7";
		return $this->db->getResults($query, 'array');
	}
	
}

?>