<?php
include_once '../model/finders/Finder.php';

if(isset($_GET['sourceID']) && isset($_GET['destID'])){ //reads the HTTP request parameters
	$finder = new Finder();
	$result = $finder->findRoute($_GET['sourceID'], $_GET['destID']); // request finder to find the route
	$count = 1;
	array_pop($result);
	$route_model = new RouteModel();
	$node_model = new HaltModel();
	
        echo "|";
        
	while ($bus = array_pop($result)) {
		$to = $node_model->getHalt($bus->getID());
		$from = $node_model->getHalt($bus->getHaltCameFrom());
		$route = $route_model->getRoutesByID($bus->getRouteCameFrom());
		echo "$route->description:$from->name:$to->name";//formatting the output
                echo "|";
		$count++;
	}
	
}

?>